from NovaHelper import stc

from NovaSystem import NovaSystem

stc(f"Welcome to the NovaSystem.")
