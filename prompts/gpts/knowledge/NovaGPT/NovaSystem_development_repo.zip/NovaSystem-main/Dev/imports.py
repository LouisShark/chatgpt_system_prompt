# Imports and Dependencies
import os
import sys
import time
import random
import datetime
import webbrowser
import subprocess
import speech_recognition as sr
import pyttsx3
import pywhatkit
import wikipedia
import pyjokes
import pyautogui
import requests
import pyowm
import wolframalpha
import smtplib
import pyaudio
import json
import psutil
import pyautogui
import pygetwindow as gw
import pyperclip
import pyshorteners
import pyqrcode
import pyzbar.pyzbar as pyzbar
import cv2
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import matplotlib.animation as animation
from matplotlib import style
from matplotlib import rc
from matplotlib import pyplot as plt
from matplotlib import patches as mpatches
from matplotlib import pyplot as plt
from matplotlib import cm
from matplotlib import gridspec
from matplotlib import ticker, cm as mpl_rc, colors, colorbar, patches, rc as mpl_rc, pyplot as plt, style, rcParams as mpl_rcParams, animation


# Importing the required modules
from tkinter import *

# Import SDK packages
from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient

# Importing the required modules
