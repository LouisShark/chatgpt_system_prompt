# External Modified Libraries

This folder contains modified versions of external libraries. The modifications are done to make the libraries compatible with the project.

## Libraries
---
### Ghost
The Ghost library can generate newsletters with AI. The original library can be found [here](https://github.com/TryGhost/Ghost)

### Fig-Autocomplete