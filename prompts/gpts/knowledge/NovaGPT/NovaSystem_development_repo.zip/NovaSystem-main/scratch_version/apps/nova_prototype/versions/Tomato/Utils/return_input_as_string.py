def return_input_as_string(input, verbose=False):
    stringified_input = str(input)
    if verbose:
        print(f"Debug: Input {input} was converted to {stringified_input}")
    return stringified_input

