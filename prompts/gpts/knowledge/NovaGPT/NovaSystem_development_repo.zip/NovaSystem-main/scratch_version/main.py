from uuid import uuid4
from apps.nova_prototype.versions.Tomato.nova_tomato import App

result = App()

print(result)
print(result.id)